﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zkouska
{
    class Program
    {
        static void Main(string[] args)
        {
            string znaminko;
            int guessCount = 0;
            int guessLimit = 5;
            bool outOfGuess = false;

            while (znaminko != (+-* /) && !outOfGuess)
            {
                if (znaminko == "+, -, *, /")
                {
                    Console.WriteLine("Jakou pocetni operaci chcete provest? (+ - * /)");
                    znaminko = Console.ReadLine();
                    guessCount++;

                }
                else if
                {
                    Console.WriteLine("Spatne zadano");
                } else
                {
                    outOfGuess = true;
                }
                Console.WriteLine("Napiste prvni cislo");
                double cislo1 = Convert.ToDouble(Console.ReadLine());

                while (cislo1)
                    if (cislo1 == cislo1)
                    {
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("Spatne zadano");
                    }

                Console.WriteLine("Napiste druhe cislo");
                double cislo2 = Convert.ToDouble(Console.ReadLine());

                if (cislo2 == cislo2)
                {
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Spatne zadano");
                }


                if (znaminko == "+")
                {
                    Console.WriteLine("{0} + {1} = {2}", cislo1, cislo2, cislo1 + cislo2);
                }
                else if (znaminko == "-")
                {
                    Console.WriteLine("{0} - {1} = {2}", cislo1, cislo2, cislo1 - cislo2);
                }
                else if (znaminko == "*")
                {
                    Console.WriteLine("{0} * {1} = {2}", cislo1, cislo2, cislo1 * cislo2);
                }
                else if (znaminko == "/")
                {
                    Console.WriteLine("{0} / {1} = {2}", cislo1, cislo2, cislo1 / cislo2);
                }
                else
                {
                    Console.WriteLine("Spatne zadano");
                }

                Console.ReadKey();
                Console.ReadLine();
            }
        }
    }
}
